var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');


var indexRouter = require('./routes/index');
var LoginRouter = require('./routes/Login');
var signupRouter = require('./routes/signup');
var dashboardRouter = require('./routes/dashboard');
var addDesignationRouter = require('./routes/addDesignation');
var addDepartmentRouter = require('./routes/addDepartment');
var registerEmployeeRouter = require('./routes/registerEmployee');
var viewDesignationRouter = require('./routes/viewDesignation');
var viewDepartmentRouter = require('./routes/viewDepartment');
var viewAllEmployeeRouter = require('./routes/viewAllEmployee');
var assignSalaryRouter = require('./routes/assignSalary');
var viewSalaryRouter = require('./routes/viewSalary');
var usersRouter = require('./routes/users');

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/Login', LoginRouter);
app.use('/signup', signupRouter);
app.use('/dashboard', dashboardRouter);
app.use('/addDesignation', addDesignationRouter);
app.use('/addDepartment', addDepartmentRouter);
app.use('/registerEmployee', registerEmployeeRouter);
app.use('/viewDesignation', viewDesignationRouter);
app.use('/viewDepartment', viewDepartmentRouter);
app.use('/viewAllEmployee', viewAllEmployeeRouter);
app.use('/assignSalary', assignSalaryRouter);
app.use('/viewSalary', viewSalaryRouter);
app.use('/users', usersRouter);

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
