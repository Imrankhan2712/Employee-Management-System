var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getCategoryName = DesignationModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});


if (typeof localStorage === "undefined" || localStorage === null) {
  var LocalStorage = require('node-localstorage').LocalStorage;
  localStorage = new LocalStorage('./scratch');
}


//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/Login');
  }
  next();
}

function checkUsername(req,res,next)
{ 
  var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}


router.get('/', function(req, res, next) {
  var userlogin = localStorage.getItem('userlogin');
  if(userlogin)
  {
    res.redirect('./dashboard');
  }
  else
  {
    res.render('Login', { title: 'Employee Management System', msg:''});
  }
  
});

router.post('/', function(req, res, next) {
  var username = req.body.username;
  var password = req.body.password;

  var checkUsername = signupModule.findOne({username:username});

  checkUsername.exec(function(err,data)
  {

    if(data==null)
    {
      res.render('Login', { title: 'Employee Management System', msg:"Invalid Username!", flaglogin:0 });
  
    }
    else
    {
      if(err) throw err;
      var getPassword = data.password;
      var getID = data._id;
      if(bcrypt.compareSync(password,getPassword))
      {
        var token = jwt.sign({ userID: 'getID' }, 'loginToken');
        localStorage.setItem('userToken', token);
        localStorage.setItem('userlogin', username);
  
        res.redirect('/dashboard');
      }
      else
      {
        res.render('Login', { title: 'Employee Management System', msg:'Invalid Password!', flaglogin:0 });
      }
    }
    
  });
});








module.exports = router;
