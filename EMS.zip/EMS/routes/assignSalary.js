var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getDesignation = DesignationModule.find({});
var getDepartment = DepartmentModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});
var getSalary = salaryModule.find({});


//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/cover');
  }
  next();
}

function checkUsername(req,res,next)
{ var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}

if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = new LocalStorage('./scratch');
  }


  router.get('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    getRegisterEmployee.exec(function(err, data)
    {
      if(err) throw err;
      res.render('assignSalary', { title: 'Employee Management System', userlogin:userlogin, records:data });
    });
    
  });
  


  router.get('/employeeSalary/:id', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    var passID = req.params.id;
    var getID = registerEmployeeModule.findById(passID);
    getID.exec(function(err, data)
    {
      if(err) throw err;
      res.render('employeeSalary', { title: 'Employee Management System', userlogin:userlogin, EmployeeRecords:data, id:passID});
         
    })
});


router.post('/employeeSalary/', checkLogin, function(req, res, next) {
  var userlogin = localStorage.getItem('userlogin');
  var id_number = req.body.id_number;
  var department = req.body.department;
  var designation = req.body.designation;
  var full_name = req.body.full_name;
  var basic_pay = req.body.basic_pay;
  var dearness_allowance = req.body.dearness_allowance;
  var home_rent_allowance = req.body.home_rent_allowance;
  var medical_allowance = req.body.medical_allowance;
  var conveyance_allowance = req.body.conveyance_allowance;
  var overtime_allowance = req.body.overtime_allowance;
  var bonus = req.body.bonus;
  var national_insurance = req.body.national_insurance;
  var provident_fund = req.body.provident_fund;
  var income_tax = req.body.income_tax;
  var loan = req.body.loan;
  var food_allowance = req.body.food_allowance;
  var total_earning = parseFloat(req.body.basic_pay) + 
                      parseFloat(req.body.dearness_allowance) + 
                      parseFloat(req.body.home_rent_allowance) + 
                      parseFloat(req.body.medical_allowance) +
                      parseFloat(req.body.conveyance_allowance) +
                      parseFloat(req.body.overtime_allowance) +
                      parseFloat(req.body.bonus);

  var total_deduction = parseFloat(req.body.national_insurance) + 
                        parseFloat(req.body.provident_fund) + 
                        parseFloat(req.body.income_tax) + 
                        parseFloat(req.body.loan) +
                        parseFloat(req.body.food_allowance);

  var net_payable = total_earning - total_deduction;
    
  

  var assignSalary = new salaryModule({
    ID_Number:id_number,
    Designation:designation,
    Department:department,
    Full_Name:full_name,
    Basic_Pay:basic_pay,
    Dearness_Allowance:dearness_allowance,
    Home_Rent_Allowance:home_rent_allowance,
    Medical_Allowance:medical_allowance,
    Conveyance_Allowance:conveyance_allowance,
    Overtime_Allowance:overtime_allowance,
    Bonus:bonus,
    National_Insurance:national_insurance,
    Provident_Fund:provident_fund,
    Income_Tax:income_tax,
    Loan:loan,
    Food_Allowance:food_allowance,
    Total_Earning:total_earning,
    Total_Deduction:total_deduction,
    Net_Payable:net_payable,
                    
  });
  assignSalary.save(function(err, data)
  {
    if(err) throw err;
    res.redirect('/assignSalary');
  });
});

  
  

  module.exports = router;