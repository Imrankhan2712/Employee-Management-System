var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getDesignation = DesignationModule.find({});
var getDepartment = DepartmentModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});


//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/cover');
  }
  next();
}

function checkUsername(req,res,next)
{ var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}

if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = new LocalStorage('./scratch');
  }


  router.get('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    getRegisterEmployee.exec(function(err, data)
    {
      if(err) throw err;
      res.render('viewAllEmployee', { title: 'Employee Management System', userlogin:userlogin, msg:'', records:data });
    });
    
  });
  
  
  router.get('/delete/:id', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
  
    var passID = req.params.id;
    var passDeleteID = registerEmployeeModule.findByIdAndDelete(passID);
    passDeleteID.exec(function(err)
    {
      if(err) throw err;
      res.redirect('/viewAllEmployee');
    });
    
  });

  router.get('/edit/:id', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    var passID = req.params.id;
    var getID = registerEmployeeModule.findById(passID);
    getID.exec(function(err, data)
    {
      getDesignation.exec(function(err, DesignationRecords)
      {
        getDepartment.exec(function(err, DepartmentRecords)
        {
          if(err) throw err;
          res.render('updateEmployeeINFO', { title: 'Employee Management System', userlogin:userlogin, msg:'', EmployeeRecords:data, DesignationRecords:DesignationRecords, DepartmentRecords:DepartmentRecords, id:passID });
        })
      })
    });
  });
  
  router.post('/edit/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    var passID = req.body.id;
    var id_number = req.body.id_number;
    var designation = req.body.designation;
    var department = req.body.department
    var full_name = req.body.full_name;
    var email = req.body.email;
    var contact = req.body.contact;
    var address = req.body.address;

    var updateCategory = registerEmployeeModule.findByIdAndUpdate(passID,{
      ID_Number:id_number,
      Designation:designation,
      Department:department,
      Full_Name:full_name,
      Email:email,
      Contact_No:contact,
      Address:address,
    });
    updateCategory.exec(function(err, data)
    {
      if(err) throw err;
      res.redirect('/viewAllEmployee');
    });
  });

  module.exports = router;