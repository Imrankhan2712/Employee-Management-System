var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getDesignation = DesignationModule.find({});
var getDepartment = DepartmentModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});

//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/');
  }
  next();
}

function checkUsername(req,res,next)
{ var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}

if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = new LocalStorage('./scratch');
  }


  router.get('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    getDesignation.exec(function(err, DesignationRecords)
    {
      getDepartment.exec(function(err, DepartmentRecords)
      {
        if(err) throw err;
        res.render('registerEmployee', { title: 'Employee Management System', userlogin:userlogin, msg:"", DesignationRecords:DesignationRecords, DepartmentRecords:DepartmentRecords });
      })
    })

  });
  
  router.post('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');

    var id_number = req.body.id_number;
    var designation = req.body.designation;
    var department = req.body.department
    var full_name = req.body.full_name;
    var email = req.body.email;
    var contact = req.body.contact;
    var address = req.body.address;

    var checkID_Number = registerEmployeeModule.findOne({ ID_Number:id_number });

    checkID_Number.exec(function(err,dataID_Number)
    {
      if(dataID_Number == null)
      {
        var registerEmployeeObject = new registerEmployeeModule({
              ID_Number:id_number,
              Designation:designation,
              Department:department,
              Full_Name:full_name,
              Email:email,
              Contact_No:contact,
              Address:address,
        });

        registerEmployeeObject.save(function(err, doc)
        {
          getDesignation.exec(function(err, DesignationRecords)
          {
            getDepartment.exec(function(err, DepartmentRecords)
            {
              if(err) throw err;
              res.render('registerEmployee', { title: 'Employee Management System', userlogin:userlogin, msg:'Added Successfully!', DesignationRecords:"", DepartmentRecords:"", flag:1 });
            })
          })
        });
      }

      else
      {
        getDesignation.exec(function(err, DesignationRecords)
        {
          getDepartment.exec(function(err, DepartmentRecords)
          {
            res.render('registerEmployee', { title: 'Employee Management System', userlogin:userlogin, msg:"ID Already Exist!", DesignationRecords:DesignationRecords, DepartmentRecords:DepartmentRecords, flag:0});
          })
        })
      }
    })
  });

  module.exports = router;