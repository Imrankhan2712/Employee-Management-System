var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getCategoryName = DesignationModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});


//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/cover');
  }
  next();
}

function checkUsername(req,res,next)
{ var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}

if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = new LocalStorage('./scratch');
  }


  router.get('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    
      res.render('addDesignation', { title: 'Employee Management System', userlogin:userlogin, msg:""});
      
  });
  
  router.post('/', checkLogin, function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
  
    var designation = req.body.designation;
    var checkDesignation = DesignationModule.findOne({Designation:designation});

    checkDesignation.exec(function(err,data)
    {
      if(data == null)
      {
        var DesignationObject = new DesignationModule({
          Designation:designation,
        });
    
        DesignationObject.save(function(err, doc)
        {
            if(err) throw err;
            res.render('addDesignation', { title: 'Employee Management System', userlogin:userlogin, msg:"Added Successfully!", flag:1});
            
        });
      }
      else
      {
        res.render('addDesignation', { title: 'Employee Management System', userlogin:userlogin, msg:"Already Exist!", flag:0});
      }
    });
    
  });


  

  module.exports = router;