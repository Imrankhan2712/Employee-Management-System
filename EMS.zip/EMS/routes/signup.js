var express = require('express');
var router = express.Router();
var signupModule = require('../EmployeeModule/signupSchema');
var DesignationModule = require('../EmployeeModule/DesignationSchema');
var DepartmentModule = require('../EmployeeModule/DepartmentSchema');
var registerEmployeeModule = require('../EmployeeModule/registerEmployeeSchema');
var salaryModule = require('../EmployeeModule/salarySchema');
var bcrypt = require('bcryptjs');
var jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
var getCategoryName = DesignationModule.find({});
var getRegisterEmployee = registerEmployeeModule.find({});


if (typeof localStorage === "undefined" || localStorage === null) {
  var LocalStorage = require('node-localstorage').LocalStorage;
  localStorage = new LocalStorage('./scratch');
}


//Middleware

function checkLogin(req,res,next)
{
  var userToken = localStorage.getItem('userToken');
  try {
    var decoded = jwt.verify(userToken, 'loginToken');
  } catch(err) {
    res.redirect('/signup');
  }
  next();
}

function checkUsername(req,res,next)
{ 
  var username = req.body.username;
  var checkUniqueUsername = signupModule.findOne({username:username});
  checkUniqueUsername.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Username Already Exist!', flagsignup:0});
    }
    next();
  });
  
}


function checkEmail(req,res,next)
{ var email = req.body.email;
  var checkUniqueEmail = signupModule.findOne({email:email});
  checkUniqueEmail.exec(function(err,data)
  {
    if(err) throw err;
    if(data)
    {
      return res.render('signup', { title: 'Employee Management System', msg:'Email Already Exist!', flagsignup:0 });
    }
    next();
  });
  
}


router.get('/', function(req, res, next) {
    var userlogin = localStorage.getItem('userlogin');
    if(userlogin)
    {
      res.redirect('./dashboard');
    }
    else
    {
      res.render('signup', { title: 'Employee Management System', msg:'' });
    }
  });
  
  router.post('/', checkUsername, checkEmail, function(req, res, next) {
  
    var username=req.body.username;
    var email=req.body.email;
    var password=req.body.password;
    var confpassword=req.body.confpassword;
  
    if(password != confpassword)
    {
      res.render('signup', { title: 'Employee Management System', msg:'Password Not Matched!', flagsignup:0 });
    }
    else
    {
      password = bcrypt.hashSync(req.body.password, 10);
      var employeeDetails = new signupModule({
        username:username,
        email:email,
        password:password,
      });
    
      employeeDetails.save(function(err, res1)
      {
        if(err) throw err;
        res.render('signup', { title: 'Employee Management System', msg:'Signup Successful!', flagsignup:1 });
      })
    }
    
  });
  



  module.exports = router;