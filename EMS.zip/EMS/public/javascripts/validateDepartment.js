//Validatng Department
var department = document.getElementById("department");
var alert = document.getElementById("alert");

department.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

department.onblur = function() {
    document.getElementById("message").style.display = "none";
}

department.onkeyup = function()
{
    var letters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(department.value.match(letters)) 
    {  
        alert.classList.remove("invalid");
        alert.classList.add("valid");
    } 
    else 
    {
        alert.classList.add("invalid");
        alert.classList.remove("valid");
    }
    
}
