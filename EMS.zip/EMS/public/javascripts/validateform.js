function validateDepartment()
{
    var department = document.getElementById("department").value;

	if(department.trim()=="")
	{
        document.getElementById("department").style.border="2px solid";
		document.getElementById("department").style.borderColor="red";
		return false;
    }
    var letters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(!department.match(letters))
	{
        document.getElementById("departmentID").innerHTML="Only Letters!";
        document.getElementById("departmentID").style.color="red";
        document.getElementById("departmentID").style.fontSize="medium";
        
		return false;
    }
}



function validateDesignation()
{
    var designation = document.getElementById("designation").value;

	if(designation.trim()=="")
	{
        document.getElementById("designation").style.border="2px solid";
		document.getElementById("designation").style.borderColor="red";
		return false;
    }
    var letters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(!designation.match(letters))
	{
        document.getElementById("designationID").innerHTML="Only Letters!";
        document.getElementById("designationID").style.color="red";
        document.getElementById("designationID").style.fontSize="medium";
        
		return false;
    }
}


function validateRegisterEmployee()
{
    var id_number = document.getElementById("id_number").value;
    var designation = document.getElementById("designation").value;
    var department = document.getElementById("department").value;
    var full_name = document.getElementById("full_name").value;
    var email = document.getElementById("email").value;
    var contact = document.getElementById("contact").value;

    if(id_number.trim()=="")
	{
        document.getElementById("id_number").style.border="2px solid";
		document.getElementById("id_number").style.borderColor="red";
		return false;
    }
    if(designation.trim()=="")
	{
        document.getElementById("designation").style.border="2px solid";
		document.getElementById("designation").style.borderColor="red";
		return false;
    }
    if(department.trim()=="")
	{
        document.getElementById("department").style.border="2px solid";
		document.getElementById("department").style.borderColor="red";
		return false;
    }
    if(full_name.trim()=="")
	{
        document.getElementById("full_name").style.border="2px solid";
		document.getElementById("full_name").style.borderColor="red";
		return false;
    }
    var onlyletters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(!full_name.match(onlyletters))
	{
        document.getElementById("fullnameID").innerHTML="Only Letters!";
        document.getElementById("fullnameID").style.color="red";
        document.getElementById("fullnameID").style.fontSize="medium";
        document.getElementById("full_name").style.border="2px solid";
        document.getElementById("full_name").style.borderColor="red";
        
		return false;
    }

    
    if(email.trim()=="")
	{
        document.getElementById("email").style.border="2px solid";
		document.getElementById("email").style.borderColor="red";
		return false;
    }
    if(contact.trim()=="")
	{
        document.getElementById("contact").style.border="2px solid";
		document.getElementById("contact").style.borderColor="red";
		return false;
    }
    if(address.trim()=="")
	{
        document.getElementById("address").style.border="2px solid";
		document.getElementById("address").style.borderColor="red";
		return false;
    }

    
    

    var atposition=email.indexOf("@");  
	var dotposition=email.lastIndexOf("."); 
    
    if(atposition<1 || dotposition<atposition+2 || dotposition+2>=email.length)
	{ 
		document.getElementById("emailID").innerHTML="Invalid!";
        document.getElementById("emailID").style.color="red";
        document.getElementById("emailID").style.fontSize="medium";
        document.getElementById("email").style.border="2px solid";
        document.getElementById("email").style.borderColor="red"; 
        return false;  
    }

    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(!contact.match(phoneno))
    {
        document.getElementById("contactID").innerHTML="Invalid!";
        document.getElementById("contactID").style.color="red";
        document.getElementById("contactID").style.fontSize="medium";
        document.getElementById("contact").style.border="2px solid";
        document.getElementById("contact").style.borderColor="red"; 
        return false; 
    }

}