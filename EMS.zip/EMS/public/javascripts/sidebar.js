
$('.department-btn').click(function(){
	$('nav ul .department-show').toggleClass("showDepartment");
	$('nav ul .first').toggleClass("rotate");
});

$('.designation-btn').click(function(){
	$('nav ul .designation-show').toggleClass("showDesignation");
	$('nav ul .second').toggleClass("rotate");
});

$('.employee-btn').click(function(){
	$('nav ul .employee-show').toggleClass("showEmployee");
	$('nav ul .third').toggleClass("rotate");
});

$('.salary-btn').click(function(){
	$('nav ul .salary-show').toggleClass("showSalary");
	$('nav ul .fourth').toggleClass("rotate");
});

$('nav ul li').click(function(){
	$(this).addClass("active").siblings().removeClass("active");
})