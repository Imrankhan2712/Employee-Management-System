function validateEmployee()
{
    var id_number = document.getElementById("id_number").value;
    var designation = document.getElementById("designation").value;
    var department = document.getElementById("department").value;
    var full_name = document.getElementById("full_name").value;
    var email = document.getElementById("email").value;
    var contact = document.getElementById("contact").value;
    var address = document.getElementById("address").value;

    if(id_number.trim()=="")
	{
        document.getElementById("id_number").style.border="2px solid";
		document.getElementById("id_number").style.borderColor="red";
		return false;
    }
    var wordchar = /^[a-zA-Z0-9\-/]+$/;
    if(!id_number.match(wordchar))
    {
        document.getElementById("ID_no").innerHTML="Invalid Username!";
        document.getElementById("ID_no").style.color="red";
        document.getElementById("ID_no").style.fontSize="medium";
        document.getElementById("ID_no").style.textDecoration="none";
        document.getElementById("id_number").style.border="2px solid";
        document.getElementById("id_number").style.borderColor="red";
        return false;
    }

    if(department.trim()=="")
	{
        document.getElementById("department").style.border="2px solid";
		document.getElementById("department").style.borderColor="red";
		return false;
    }

    if(designation.trim()=="")
	{
        document.getElementById("designation").style.border="2px solid";
		document.getElementById("designation").style.borderColor="red";
		return false;
    }

    if(full_name.trim()=="")
	{
        document.getElementById("full_name").style.border="2px solid";
		document.getElementById("full_name").style.borderColor="red";
		return false;
    }
    var onlyletters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(!full_name.match(onlyletters))
	{
        document.getElementById("full_nameID").innerHTML="Only Alphabets Allowed!";
        document.getElementById("full_nameID").style.color="red";
        document.getElementById("full_nameID").style.fontSize="medium";
        document.getElementById("full_nameID").style.textDecoration="none";
        document.getElementById("full_name").style.border="2px solid";
        document.getElementById("full_name").style.borderColor="red";
        
		return false;
    }

    
    if(email.trim()=="")
	{
        document.getElementById("email").style.border="2px solid";
		document.getElementById("email").style.borderColor="red";
		return false;
    }
    var check_Email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!email.match(check_Email))
	{ 
		document.getElementById("emailID").innerHTML="Invalid Email!";
        document.getElementById("emailID").style.color="red";
        document.getElementById("emailID").style.fontSize="medium";
        document.getElementById("emailID").style.textDecoration="none";
        document.getElementById("email").style.border="2px solid";
        document.getElementById("email").style.borderColor="red"; 
        return false;  
    }

    if(contact.trim()=="")
	{
        document.getElementById("contact").style.border="2px solid";
		document.getElementById("contact").style.borderColor="red";
		return false;
    }
    var phoneno = /^[6-9][0-9]{9}$/;
    if(!contact.match(phoneno))
    {
        document.getElementById("contactID").innerHTML="Invalid Contact!";
        document.getElementById("contactID").style.color="red";
        document.getElementById("contactID").style.fontSize="medium";
        document.getElementById("contactID").style.textDecoration="none";
        document.getElementById("contact").style.border="2px solid";
        document.getElementById("contact").style.borderColor="red"; 
        return false; 
    }

    if(address.trim()=="")
	{
        document.getElementById("address").style.border="2px solid";
		document.getElementById("address").style.borderColor="red";
		return false;
    }
    var check_address = /^[a-zA-Z0-9\s,.'-]{3,}$/;
    if(!address.match(check_address))
    {
        document.getElementById("addressID").innerHTML="Invalid Address!";
        document.getElementById("addressID").style.color="red";
        document.getElementById("addressID").style.fontSize="medium";
        document.getElementById("addressID").style.textDecoration="none";
        document.getElementById("address").style.border="2px solid";
        document.getElementById("address").style.borderColor="red"; 
        return false; 
    }
    
}