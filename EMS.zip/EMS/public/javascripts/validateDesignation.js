//Validatng Designation
var designation = document.getElementById("designation");
var alert = document.getElementById("alert");

designation.onfocus = function() {
    document.getElementById("message").style.display = "block";
}

designation.onblur = function() {
    document.getElementById("message").style.display = "none";
}

designation.onkeyup = function()
{
    var letters = /^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/;
    if(designation.value.match(letters)) 
    {  
        alert.classList.remove("invalid");
        alert.classList.add("valid");
    } 
    else 
    {
        alert.classList.add("invalid");
        alert.classList.remove("valid");
    }
    
}
