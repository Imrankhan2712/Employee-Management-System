function validateSignUp()
{
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;

	if(username.trim()=="")
	{
        document.getElementById("usernameID").innerHTML="No Blanks Allowed!";
        document.getElementById("usernameID").style.color="red";
        document.getElementById("usernameID").style.fontSize="small";
        document.getElementById("usernameID").style.backgroundColor="black";
        document.getElementById("usernameID").style.marginRight="-13rem";
		return false;
    }

    var illegalChars = /\W/;
    if ((username.length < 5) || (username.length > 15)) 
    {
        
        document.getElementById("usernameID").innerHTML="Wrong Length!";
        document.getElementById("usernameID").style.color="red";
        document.getElementById("usernameID").style.fontSize="small";
        document.getElementById("usernameID").style.backgroundColor="black";
        document.getElementById("usernameID").style.marginRight="-15rem";

		return false;
 
    }
    if (illegalChars.test(username)) 
    {
        document.getElementById("usernameID").innerHTML="No Characters Allowed!";
        document.getElementById("usernameID").style.color="red";
        document.getElementById("usernameID").style.fontSize="small";
        document.getElementById("usernameID").style.backgroundColor="black";
        document.getElementById("usernameID").style.marginRight="-11rem";
		return false;
 
    }


    if(email.trim()=="")
	{
        document.getElementById("emailID").innerHTML="No Blanks Allowed!";
        document.getElementById("emailID").style.color="red";
        document.getElementById("emailID").style.fontSize="small";
        document.getElementById("emailID").style.backgroundColor="black";
        document.getElementById("emailID").style.marginRight="-13rem";
		return false;
    }

    var check_email = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    
    if(!email.match(check_email))
	{ 
		document.getElementById("emailID").innerHTML="Invalid!";
        document.getElementById("emailID").style.color="red";
        document.getElementById("emailID").style.fontSize="small";
        document.getElementById("emailID").style.backgroundColor="black";
        document.getElementById("emailID").style.marginRight="-17.5rem";

        return false;  
    }


    if(password.trim()=="")
	{
        document.getElementById("passwordID").innerHTML="No Blanks Allowed!";
        document.getElementById("passwordID").style.color="red";
        document.getElementById("passwordID").style.fontSize="small";
        document.getElementById("passwordID").style.backgroundColor="black";
        document.getElementById("passwordID").style.marginRight="-13rem";
		return false;
    }
    
   
}

function showPassword()
{
    var pass = document.getElementById("password");
    if (pass.type === "password")
    {
      pass.type = "text";
    }
    else 
    {
        pass.type = "password";
    }
}