var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Employee_Management_System', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
var conn = mongoose.Collection;

var signupSchema = new mongoose.Schema({
    username:{
        type:String,
        require:true,
        index:{
            unique:true,
        }
    },

    email:{
        type:String,
        required:true,
        index:{
            unique:true,
        }
    },

    password:{
        type:String,
        required:true
    },

    date:{
        type:Date,
        default: Date.now
    }
});

var signupModel = mongoose.model('Signup_Records', signupSchema);
module.exports = signupModel;