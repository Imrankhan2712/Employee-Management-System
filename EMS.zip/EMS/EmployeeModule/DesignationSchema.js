var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Employee_Management_System', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
var conn = mongoose.Collection;

var DesignationSchema = new mongoose.Schema({
    Designation:{
        type:String,
        require:true,
        index:{
            unique:true,
        }
    },

    Date:{
        type:Date,
        default: Date.now
    }
});

var DesignationModel = mongoose.model('Employee_Designation', DesignationSchema);
module.exports = DesignationModel;