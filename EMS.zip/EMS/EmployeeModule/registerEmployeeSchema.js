var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Employee_Management_System', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
var conn = mongoose.Collection;

var registerEmployeeSchema = new mongoose.Schema({
    ID_Number:{
        type:String,
        require:true,
        index:{
            unique:true,
        }
    },

    Designation:{
        type:String,
        required:true,
    },

    Department:{
        type:String,
        required:true,
    },

    Full_Name:{
        type:String,
        required:true
    },

    Contact_No:{
        type:Number,
        required:true,
        index:{
            unique:true,
        }
    },

    Email:{
        type:String,
        required:true,
        index:{
            unique:true,
        }
    },


    Address:{
        type:String,
        required:true
    },
 
    Date:{
        type:Date,
        default: Date.now
    }
});

var registerEmployeeModel = mongoose.model('Employee_Records', registerEmployeeSchema);
module.exports = registerEmployeeModel;