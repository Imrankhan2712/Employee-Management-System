var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Employee_Management_System', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
var conn = mongoose.Collection;

var salarySchema = new mongoose.Schema({
    ID_Number:{
        type:String,
        require:true,
    },

    Department:{
        type:String,
        required:true,
    },

    Designation:{
        type:String,
        required:true,
    },

    
    Full_Name:{
        type:String,
        required:true
    },

    Basic_Pay:{
        type:Number,
        required:true,
        
    },

    Dearness_Allowance:{
        type:Number,
        required:true,
        
    },

    Home_Rent_Allowance:{
        type:Number,
        required:true,
        
    },

    Medical_Allowance:{
        type:Number,
        required:true,
        
    },

    Conveyance_Allowance:{
        type:Number,
        required:true,
        
    },

    Overtime_Allowance:{
        type:Number,
        required:true,
        
    },

    Bonus:{
        type:Number,
        required:true,
        
    },

    National_Insurance:{
        type:Number,
        required:true,
        
    },

    Provident_Fund:{
        type:Number,
        required:true,
        
    },

    Income_Tax:{
        type:Number,
        required:true,
        
    },

    Loan:{
        type:Number,
        required:true,
        
    },

    Food_Allowance:{
        type:Number,
        required:true,
        
    },

    Total_Earning:{
        type:Number,
        required:true,
        
    },

    Total_Deduction:{
        type:Number,
        required:true,
        
    },

    Net_Payable:{
        type:Number,
        required:true,
        
    },
    
    Date:{
        type:Date,
        default: Date.now
    }
});

var salaryModel = mongoose.model('Employee_Salary', salarySchema);
module.exports = salaryModel;