var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/Employee_Management_System', {useNewUrlParser: true, useUnifiedTopology: true, useCreateIndex: true});
var conn = mongoose.Collection;

var DepartmentSchema = new mongoose.Schema({
    Department:{
        type:String,
        require:true,
    },

    Date:{
        type:Date,
        default: Date.now
    }
});

var DepartmentModel = mongoose.model('Employee_Department', DepartmentSchema);
module.exports = DepartmentModel;